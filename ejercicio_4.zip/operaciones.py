class Operaciones:
    def suma(self, a, b):
        print(a + b)
        
    def resta(self, a, b):
        print(a - b)
        
    def multiplicacion(self, a, b):
        print(a * b)
        
    def division(self, a, b):
        print(a / b)
