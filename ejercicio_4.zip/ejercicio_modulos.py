import operaciones

resultado = operaciones.Operaciones()

print('suma: ')
resultado.suma(2, 3)

print('resta: ')
resultado.resta(7, 2)

print('multiplicacion: ')
resultado.multiplicacion(6, 8)

print('division: ')
resultado.division(9, 3)